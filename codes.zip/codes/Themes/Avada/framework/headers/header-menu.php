<?php global $data; ?>
<div class='top-menu'><?php wp_nav_menu(array('theme_location' => 'top_navigation', 'depth' => 2, 'container' => false, 'menu_id' => 'snav')); ?></div>