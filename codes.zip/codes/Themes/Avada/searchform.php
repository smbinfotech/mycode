<form class="search" action="<?php echo home_url(); ?>/" method="get">
	<fieldset>
		<span class="text"><input name="s" id="s" type="text" value="" placeholder="<?php echo __('Search ...', 'Avada'); ?>" /></span>
	</fieldset>
</form>